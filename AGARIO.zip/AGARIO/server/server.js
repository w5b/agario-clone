const express = require("express");
const app = express();
const server = app.listen(4000);
const io = require("socket.io")(server);
app.use(express.static("../client"));
let players = [];
let blobs = [];

class blob {
  constructor(position, size, color) {
    this.position = {
      x: position.x,
      y: position.y,
    };
    this.size = size;
    this.color = color;
  }
}

class player {
  constructor(id, position, size, color, mouse) {
    this.id = id;
    this.position = {
      x: position.x,
      y: position.y,
    };
    this.size = size;
    this.color = color;
    this.mouse = {
      x: mouse.x,
      y: mouse.y,
    };
  }
}

function getPlayerById(id) {
  return players.find((plr) => {
    return plr.id === id;
  });
}

function spawnBlobs(amount) {
  for (let i = 0; i < amount; i++) {
    blobs.push(
      new blob(
        { x: Math.random() * 3000, y: Math.random() * 3000 },
        10,
        "#" + Math.floor(Math.random() * 16777215).toString(16)
      )
    );
  }
}

const collidesWith = (player) => {
  blobs.forEach((bloba) => {
    let distance = {
      x: player.position.x - bloba.position.x,
      y: player.position.y - bloba.position.y,
    };
    let final = Math.sqrt(distance.x * distance.x + distance.y * distance.y);
    let radiusSum = player.size + bloba.size;
    if (final <= radiusSum) {
      blobs.splice(blobs.indexOf(bloba), 1);
      blobs.push(
        new blob(
          { x: Math.random() * 3000, y: Math.random() * 3000 },
          10,
          "#" + Math.floor(Math.random() * 16777215).toString(16)
        )
      );
      let sum =
        Math.PI * Math.pow(player.size, 2) + Math.PI * Math.pow(bloba.size, 2);
      player.size = Math.sqrt(sum / Math.PI);
    }
  });
};

spawnBlobs(500);

io.on("connection", (ws) => {
  console.log(`[SERVER]  Connected to client: ${ws.id}`);
  players.push(
    new player(
      ws.id,
      { x: Math.random() * 100, y: Math.random() * 100 },
      100,
      "black",
      { x: 0, y: 0 }
    )
  );
  ws.on("mouse", (data) => {
    players.forEach((plr) => {
      plr.mouse.x = data.x;
      plr.mouse.y = data.y;
      plr.mouse.canvasW = data.canvasW;
      plr.mouse.canvasH = data.canvasH;
    });
    getPlayerById(ws.id).distance = {
      x: getPlayerById(ws.id).mouse.x - getPlayerById(ws.id).mouse.canvasW / 2,
      y: getPlayerById(ws.id).mouse.y - getPlayerById(ws.id).mouse.canvasH / 2,
    };
    getPlayerById(ws.id).vector = Math.sqrt(
      Math.pow(getPlayerById(ws.id).distance.x, 2) +
        Math.pow(getPlayerById(ws.id).distance.y, 2)
    );
    getPlayerById(ws.id).speed = 1;
    if (getPlayerById(ws.id).vector > getPlayerById(ws.id).speed) {
      getPlayerById(ws.id).distance.x =
        (getPlayerById(ws.id).speed * getPlayerById(ws.id).distance.x) /
        getPlayerById(ws.id).vector;
      getPlayerById(ws.id).distance.y =
        (getPlayerById(ws.id).speed * getPlayerById(ws.id).distance.y) /
        getPlayerById(ws.id).vector;
    }
    getPlayerById(ws.id).position.x += getPlayerById(ws.id).distance.x;
    getPlayerById(ws.id).position.y += getPlayerById(ws.id).distance.y;
    collidesWith(getPlayerById(ws.id));
    ws.emit("blobs", blobs);
    io.sockets.emit("draw", players);
  });
  ws.on("disconnect", () => {
    console.log(`[SERVER]  Disconnected from client: ${ws.id}`);
    players.splice(
      players.findIndex((plr) => plr.id === ws.id),
      1
    );
  });
});
