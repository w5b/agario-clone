const ws = io("http://localhost:4000");
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
let w = canvas.width;
let h = canvas.height;
let mouse;
let players;
let blobs;
ws.on("connect", () => {
  console.log("Connected to server");
});

ws.on("draw", (data) => {
  players = data;
});

ws.on("blobs", (data) => {
  blobs = data;
});

const getPlayerById = (id) => {
  return players.find((plr) => {
    return plr.id == id;
  });
};

window.onresize = () => {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  w = canvas.width;
  h = canvas.height;
};

const update = () => {
  ctx.clearRect(0, 0, w, h);
};

const draw = (position, size, color) => {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(position.x, position.y, size, 0, 2 * Math.PI, false);
  ctx.fill();
};

const main = () => {
  update();
  if (mouse) {
    ws.emit("mouse", mouse);
  }
  if (players) {
    ctx.save();
    ctx.translate(w / 2, h / 2);
    ctx.scale(130 / getPlayerById(ws.id).size, 130 / getPlayerById(ws.id).size);
    try {
      ctx.translate(
        -getPlayerById(ws.id).position.x,
        -getPlayerById(ws.id).position.y
      );

      blobs.forEach((blob) => {
        draw({ x: blob.position.x, y: blob.position.y }, blob.size, blob.color);
      });
      players.forEach((plr) => {
        plr.color = plr.id == ws.id ? "blue" : "green";
        draw({ x: plr.position.x, y: plr.position.y }, plr.size, plr.color);
      });
      ctx.restore();
    } catch {
      location.reload();
      return;
    }
  }
  requestAnimationFrame(main);
};
main();
document.addEventListener("mousemove", (e) => {
  let rect = canvas.getBoundingClientRect();
  mouse = {
    x: e.clientX - rect.left,
    y: e.clientY - rect.top,
    canvasW: canvas.width,
    canvasH: canvas.height,
  };
});
